// @flow

import variable from "./../variables/platform";

export default (variables /*: * */ = variable) => {
  const switchTheme = {
    marginVertical: -5,
  };

  return switchTheme;
};
